class emp
{
	 static int id;
     static String name;
	 static String company;
	 static String sal;
     public void setemp(int no,String na,String Sa,String comp)
     {
             id = no;
             name = na;
             sal= Sa;
             company=comp;
             
     }
} 

public class singleinheritanceex extends emp {

	public static void main(String[] args) 
	{
		emp s = new emp();
		s.setemp(1,"nandha","1000","veetech");
		
	    
	             System.out.println("empid : " + id);
	             System.out.println("emp Name : " + name);
	             System.out.println("company name : " + company);
	             System.out.println("salary : " + sal);
	
	}
		// TODO Auto-generated method stub

	

}
