package abstractassessment;

public class Main
{
	public static void main(String[] args)
	{
		Employee contractor = new Contractor("david", 10, 10);
		Employee fullTimeEmployee = new FullTimeEmployee("nandha", 8);
		System.out.println(contractor.calculateSalary());
		System.out.println(fullTimeEmployee.calculateSalary()); 
	}
	}


