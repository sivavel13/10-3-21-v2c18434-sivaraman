package polyassess;

class su {
	  static int add(int a, int b)
	 {
		 return a + b;
	 }
	  static int add(int a, int b, int c) 
	 {
		 return a + b + c;
		 }
	 }
public class prebind 
{
	public static void main(String[] args)
	{
		System.out.println(su.add(11, 11));
		System.out.println(su.add(11, 31, 11));
		}
	}


